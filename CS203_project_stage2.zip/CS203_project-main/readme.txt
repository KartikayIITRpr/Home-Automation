What is done ???

1. Module definitions of basic components like multiplexer(both 8 to 1 and 2 to 1) and demultiplexer are added in the code .

2. There is a main module named 'smart_home'. This module acts as a driver module and controls all other functions of the smart home. All the inputs to other functions are given through smart_home module.

3. The work related to password field, including reset password, is completed.

4. All module names along with their respective inputs and outputs have been specified. 

5. Test bench for "password_check" module is done with different scenarios. 

6. Commented about each modules' purpose to make it easy for the reader or checker to get what we are doing (or attempting to do). 

What needs to be done ???

1. Module definitions for all automations in smart home.

2. Test benches of modules except "password_check" module. 